
Đây là một web phim do nhóm chúng em tạo ra lấy cảm hứng từ Netflix dùng Firebase.

############################################################

Danh sách thành viên:
Trương Đình Văn - 52100369
Ngô Văn Danh - 52100877
Trần Quang Đãng - 52100174

############################################################

Đảm bảo rằng trên máy đã có Nodejs và npm trước khi chạy web.

############################################################

# Hướng dẫn chạy dự án

Mở "cmd" tại đường dẫn chứa file "package.json". Trường hợp này nó sẽ nằm trong thư mục source.
Trong "cmd" gõ lệnh "npm install", enter, tiếp đó gõ "npm start run", enter.
Cho phép qua tường lửa (nếu có).

# Lưu ý: 
Vì đã cấu hình sẵn nên ta có thể chạy ngay. 
Nếu muốn cấu hình Firebase lại từ đầu, hãy đọc thêm README.md trong folder source.


