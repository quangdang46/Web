# Hướng dẫn chạy dự án
## Cấu hình key api The Movie Database(TMDb)
- Đăng kí tài khoản [TMDb](https://www.themoviedb.org/)
- Tạo API Key [Api](https://www.themoviedb.org/settings/api)
- Đặt tên Api và xác nhận sau đó sẽ nhận được key

```javascript
# cấu hình key api tại đường dẫn src\api\configApi.js
const API_KEY = "a8ee03e8420a8c4b12cd8edf16b4a3aa";#Key api TMDb
const IMAGE_URL = "https://image.tmdb.org/t/p";
const EMBED_TO = "https://www.2embed.to/embed/tmdb";
const youtubePath = (videoId) =>
  `https://www.youtube.com/embed/${videoId}?controls=0`;
export { API_KEY, IMAGE_URL, EMBED_TO, youtubePath };
```

## Cấu hình firebase cho web
- Truy cập vào trang web của Firebase [Firebase](https://firebase.google.com/).
- Chọn "Get started" và tạo một dự án mới trên Firebase Console.
- Sau khi tạo dự án, chọn "Add app" và chọn "Web". Đặt tên cho ứng dụng web.
- Sao chép mã cấu hình Firebase từ Firebase Console và thêm vào trong phần cấu hình của ứng dụng web.
```javascript
# cấu hình firebase tại đường dẫn src\fire-base\firebase-config.js
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Cấu hỉnh firebase ở đây
const firebaseConfig = {
  apiKey: "AIzaSyA5LORAHta2ZOsoGsF0AyiYjydSodQO-Bg",
  authDomain: "movie-3d92e.firebaseapp.com",
  projectId: "movie-3d92e",
  storageBucket: "movie-3d92e.appspot.com",
  messagingSenderId: "920537393043",
  appId: "1:920537393043:web:a35583200d3856f0bfaa66",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// Init services
export const db = getFirestore(app);
export const auth = getAuth(app);
```
## Cấu hình database trong firebase
- Sau khi tạo dự án, chọn "Firestore Database" trong menu trái của Firebase Console.
- Firestore cung cấp hai chế độ lưu trữ: "Production" và "Test". Chế độ "Production" được sử dụng để lưu trữ dữ liệu thực tế của ứng dụng, trong khi chế độ "Test" được sử dụng để lưu trữ dữ liệu của ứng dụng trong quá trình phát triển và kiểm tra.
- Firestore cung cấp các quyền truy cập để bạn có thể quản lý người dùng và cho phép họ truy cập vào dữ liệu của bạn. Bạn có thể cấu hình các quyền truy cập này trong phần "Rules" của Firestore.
- Tạo `collection` có tên là `users` gồm các field :`bookmarks(array)`,`email(string)`,`name(string)`,`password(string)`,`photoURL(string)`,`recentlyWatch(array)`,`username(string)`

## Cách chạy dự án
- Cài đặt Node.js tại [đây](https://nodejs.org/en/)
- Cài đặt các gói phụ thuộc
```javascript
npm install
```
- Chạy dự án
```javascript
npm start
```