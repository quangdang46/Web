export { default as SimpleBreadcrumbs } from "./SimpleBreadcrumbs";
