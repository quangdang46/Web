const API_KEY = "a8ee03e8420a8c4b12cd8edf16b4a3aa";
const IMAGE_URL = "https://image.tmdb.org/t/p";
const EMBED_TO = "https://www.2embed.to/embed/tmdb";
const youtubePath = (videoId) =>
  `https://www.youtube.com/embed/${videoId}?controls=0`;
export { API_KEY, IMAGE_URL, EMBED_TO, youtubePath };
