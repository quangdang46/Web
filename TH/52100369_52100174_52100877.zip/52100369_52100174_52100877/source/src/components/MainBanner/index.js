export { default as MainBanner } from "./MainBanner";
