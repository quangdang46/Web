export { default as CustomModal } from "./CustomModal";
